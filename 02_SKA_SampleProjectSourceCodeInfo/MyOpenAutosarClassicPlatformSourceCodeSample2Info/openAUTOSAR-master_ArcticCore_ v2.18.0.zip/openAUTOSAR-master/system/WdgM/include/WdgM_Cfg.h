/********************************************************************
 * TODO
 * The constants below are not defined in the code base from Arctic
 * Their values have to be checked in real Projects
 * (C) DaVinci Engineering GmbH 2022
 *******************************************************************/

#ifndef WDGM_CFG_H_
#define WDGM_CFG_H_

#warning "This default file may only be used as an example!"

/********************************************************************
 * TODO
 * The constants below are not defined in the code base from Arctic
 * Their values have to be checked in real Projects
 * (C) DaVinci Engineering GmbH 2022
 *******************************************************************/
#define  WDGM_NBR_OF_WATCHDOGS   1  // Only one WD supported
#define  WDGM_NBR_OF_ALIVE_SIGNALS 4
#include "WdgM_ConfigTypes.h"


#endif /*WDGM_CFG_H_*/
