
#ifndef CRC_CFG_H_
#define CRC_CFG_H_

#define CRC_VERSION_INFO_API	STD_ON


#endif /* CRC_CFG_H_ */
