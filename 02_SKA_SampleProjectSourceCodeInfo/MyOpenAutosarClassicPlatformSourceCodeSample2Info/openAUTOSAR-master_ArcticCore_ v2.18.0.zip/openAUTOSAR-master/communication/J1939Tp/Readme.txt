#********************************************************************
# (C) DaVinci Engineering GmbH 2022
#*******************************************************************/
This folder has been kept for future reference.
The module implements requirements from Autosar 4.0.1 instead of
3.1.5 as the rest of the system