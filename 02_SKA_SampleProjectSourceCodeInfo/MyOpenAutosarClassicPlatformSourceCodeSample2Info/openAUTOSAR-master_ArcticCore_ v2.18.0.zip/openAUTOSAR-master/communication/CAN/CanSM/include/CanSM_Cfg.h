/*
 * (C) DaVinci Engineering GmbH 2022
 */
#ifndef CANSM_CFG_H_
#define CANSM_CFG_H_

/********************************************************************
 * TODO
 * The constants below are not defined in the code base from Arctic
 * Their values have to be checked in real Projects
 * (C) DaVinci Engineering GmbH 2022
 *******************************************************************/
#define CANSM_NETWORK_COUNT 10

#endif // CANSM_CFG_H_

