
/********************************************************************
 * (C) DaVinci Engineering GmbH 2022
 *******************************************************************/
#warning "This default file may only be used as an example!"


#ifndef WDGIF_CFG_H_
#define WDGIF_CFG_H_

#include "WdgIf_Types.h"

typedef struct WdgIf_ConfigType
{
	/* data */
} WdgIf_ConfigType;



#endif // WDGIF_CFG_H_
