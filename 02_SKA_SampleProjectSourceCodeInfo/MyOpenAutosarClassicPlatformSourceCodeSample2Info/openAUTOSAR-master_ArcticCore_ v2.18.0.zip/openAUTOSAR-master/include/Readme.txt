#********************************************************************
# (C) DaVinci Engineering GmbH 2022
#*******************************************************************/

This "include" folder comes from the open source code from Arctic.
Although some of then files in it have been moved to the relevant
packages after the fork, there are possibly still files that 
could be moved.
In order to be able to recompile the system and provide 
a development envirobnment as soon as possible it has been decided to
consider the handling of the include files as a work in progress,
also in the light of new hardware support 