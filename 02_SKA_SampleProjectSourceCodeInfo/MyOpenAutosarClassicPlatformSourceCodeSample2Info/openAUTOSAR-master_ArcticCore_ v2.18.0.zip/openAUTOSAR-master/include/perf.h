/*
 * Perf.h
 *
 *  Created on: 16 apr 2013
 *      Author: Mahil
 */

#ifndef PERF_H_
#define PERF_H_

void Perf_Trigger(void);
void Perf_Init( void );

#endif /* PERF_H_ */
